Set-ExecutionPolicy Unrestricted -Scope Process

python -m venv .dis_venv
.dis_venv\Scripts\activate
pip install -r requirements.txt